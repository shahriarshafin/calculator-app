/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 *
 * @author shafi
 */
public class FXMLDocumentController implements Initializable {
    float fData= 0f, lData = 0f;
     @FXML
    private TextField display;

    @FXML
    private Button one;

    @FXML
    private Button two;
    
    @FXML
    private Button three;
    
    @FXML
    private Button four;
    
    @FXML
    private Button five;
    
    @FXML
    private Button six;
    
    @FXML
    private Button seven;
    
    @FXML
    private Button eight;
    
    @FXML
    private Button nine;
    
    @FXML
    private Button zero;

    @FXML
    private Button plus;
    
    @FXML
    private Button minus;
    
    @FXML
    private Button multiplication;
    
    @FXML
    private Button devide;
    
    @FXML
    private Button equal;
    
    
    
    
    

    @FXML
    void handleButtonAction(ActionEvent event) {
        if(event.getSource()== one){
            display.setText(display.getText() + "1");
        }else if(event.getSource()== two){
            display.setText(display.getText() + "2");
        }
        else if(event.getSource()== three){
            display.setText(display.getText() + "3");
        }
        else if(event.getSource()== four){
            display.setText(display.getText() + "4");
        }
        else if(event.getSource()== five){
            display.setText(display.getText() + "5");
        }
        else if(event.getSource()== six){
            display.setText(display.getText() + "6");
        }
        else if(event.getSource()== seven){
            display.setText(display.getText() + "7");
        }
        else if(event.getSource()== eight){
            display.setText(display.getText() + "8");
        }
        else if(event.getSource()== nine){
            display.setText(display.getText() + "9");
        }
        else if(event.getSource()== zero){
            display.setText(display.getText() + "0");
        }
        
        
        
        
        
        
        if(event.getSource()== plus){
            fData = Float.parseFloat(display.getText());
            display.setText("");
        }if(event.getSource()== equal){
            lData = Float.parseFloat(display.getText());
            float answer = fData + lData;
            display.setText(String.valueOf(answer));
        }
        
        if(event.getSource()== minus){
            fData = Float.parseFloat(display.getText());
            display.setText("");
            lData = Float.parseFloat(display.getText());
            float answer;
            display.setText(String.valueOf(answer = fData - lData));
            
        }
            
        

    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
